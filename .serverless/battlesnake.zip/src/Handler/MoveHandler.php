<?php

declare(strict_types=1);

namespace App\Handler;

use App\Factory\MoveFactory;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Psr\Log\LoggerInterface;
use Slim\Psr7\Response;

class MoveHandler implements RequestHandlerInterface
{
    private LoggerInterface $logger;

    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    public function handle(ServerRequestInterface $request): ResponseInterface
    {
        $move = MoveFactory::create($request->getBody()->getContents());
        $this->logger->info('Move handler dispatched: ' . $move);
        $instruction = $this->figureOutMove();

        $response = new Response();
        $responseJson = json_encode([
            'move' => $instruction,
            'shout' => $instruction,
        ]);
        $response->getBody()->write(
            $responseJson
        );

        $this->logger->info('Response: ' . $responseJson);
        return $response;
    }

    public function figureOutMove(): string
    {
        return 'up';
    }
}
