<?php

declare(strict_types=1);

namespace App\Model;

class ProposedMove
{
    public function __construct(
        public string $direction,
        public int $food,
        public int $middle,
        public int $aggression,
        public int $cowardice,
        public int $weight
    ) {
    }
}
